#!/bin/bash
# Copyright (c) 2016 Cloudera, Inc. All rights reserved.
# Contact cert-toolkit@cloudera.com with questions
#
###############################################################################################
##     INSTALL CERTTOOLKIT DEPENDENCIES     ###################################################
###############################################################################################

set -e
set -u

BASE_DIR=$( readlink -f $( dirname $0 ) )
EXT_DIR=$BASE_DIR/ext-py

# If a virtual environment is specified in the command line, installs the Python modules
# in it. Otherwise, installs the modules in the current environment
if [ $# -gt 1 ]; then
  echo "Syntax: $0 [virtual_env_dir]"
  exit 1
fi
VENV=${1:-}

# Check if PyYAML is already available
set +e
python -c 'import pkg_resources; pkg_resources.require(["pyyaml>=3.10"])' >/dev/null 2>&1
RET=$?
set -e
if [ $RET == 0 ]; then
  IS_YAML_INSTALLED=yes
else
  IS_YAML_INSTALLED=no
fi

# Install needed OS packages
if [ -d /etc/yum.repos.d ]; then
  sudo yum -y install gcc python-devel python-setuptools
  # Avoid installing a new version of libyaml-devel, if PyYAML is already available
  if [ "$IS_YAML_INSTALLED" != "yes" ]; then
    sudo yum -y install libyaml-devel
  fi
else
  DEBIAN_FRONTEND=noninteractive sudo apt-get -y install gcc python-dev python-setuptools
  # Avoid installing a new version of libyaml-dev, if PyYAML is already available
  if [ "$IS_YAML_INSTALLED" != "yes" ]; then
    DEBIAN_FRONTEND=noninteractive sudo apt-get -y install libyaml-dev
  fi
fi

# Create virtual environment, if specified
if [ "$VENV" != "" ]; then
  # Install virtualenv, if needed
  set +e
  which virtualenv > /dev/null 2>&1
  RET=$?
  set -e
  if [ $RET != 0 ]; then
    echo "Installing virtualenv"
    sudo easy_install --allow-hosts=None --no-deps $EXT_DIR/virtualenv*.gz
  fi
  if [ ! -d $VENV ]; then
    echo "Creating virtualenv $VENV"
    virtualenv --system-site-packages $VENV
  fi
  echo "Activating virtualenv $VENV"
  set +u; source $VENV/bin/activate; set -u
fi

# Install CertToolkit dependencies
echo "Installing Python modules"
easy_install --allow-hosts=None --no-deps $EXT_DIR/*gz

# Deactivating virtualenv
if [ "$VENV" != "" ]; then
  set +u; deactivate; set -u
fi

echo "CertToolkit setup completed successfully!"
